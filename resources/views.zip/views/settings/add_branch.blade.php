@extends('main.main')
@section('address')
    <h1>إضافه فرع</h1>
@stop
@section('container')


    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if(session()->has('success'))

        <p class="alert alert-success">{{ session('success') }}</p>

    @endif

    @if(session()->has('error'))
        <p class="alert alert-danger">{{ session('error') }}</p>


    @endif
    <div class="row">
        <div class="col-lg-12 ibox float-e-margins ibox-content text-center p-md">

            <form method="post" enctype="multipart/form-data" action="{{ route('branches.store') }}">

                {{ csrf_field() }}
                <div class=" col-md-12 form-group float-e-margins">
                    <label class="font-normal col-md-2"><h4>إسم الفرع</h4></label>
                    <div class="col-md-6">
                        <input id="branch_name" placeholder="أدخل اسم الفرع " class="form-control" type="text"
                               name="branch_name">
                    </div>
                </div>
                <div class=" col-md-12 form-group float-e-margins">
                    <label class="font-normal col-md-2"><h4>إسم الفرع</h4></label>
                    <div class="col-md-6">
                        <input id="address"  name="address" placeholder="العنوان" class="form-control" type="text"
                               value="">
                    </div>
                </div>

                <div class=" col-md-12 form-group float-e-margins">
                    <label class="font-normal col-md-2"><h4>الشعار</h4></label>

                    <div class="fileinput fileinput-new col-md-4" data-provides="fileinput">
                                <span class="btn btn-default btn-file"><span
                                            class="fileinput-new">اختر الشعار</span><span
                                            class="fileinput-exists">تغيير</span>
                                    <input type="file" name="logo" class="form-control"></span>
                        <span class="fileinput-filename"></span>
                        <a href="#" class="close fileinput-exists" data-dismiss="fileinput"
                           style="float: none">&times;</a>
                    </div>


                </div>


                <button class="col-md-2 btn btn-block btn-success" style="" id="save_print">حفظ
                </button>
            </form>

        </div>

    </div>

    <hr>

    <div class="row">
        <div class="col-lg-12 ibox ibox-content ">


            <table class="table table-hover table-bordered table-striped">
                <thead>
                    <th><h3>Name</h3></th>
                    <th><h3>Address</h3></th>
                    <th><h3>Image</h3></th>
                    <th><h3>Show </h3></th>
                    <th><h3>Delete</h3></th>
                </thead>


                <tbody>

                @foreach($all_branches as $branch)
                <tr>
                    <td>{{ $branch->name }}</td>
                    <td>{{ $branch->address }}</td>
                    <td>
                        <img class="img-responsive" width="80" src="{{ url('public/img/'.$branch->logo) }}">
                    </td>
                    <td>
                        <a href="{{ route('branch.edit', [$branch->id]) }}" class="btn btn-warning">edit</a>
                    </td>
                    <td>

                        <form method="post" action="{{ route('branch.delete') }}">

                            {{ csrf_field() }}

                            <input type="hidden" name="b_id" value="{{ $branch->id }}">

                            <button type="submit">Delete</button>

                        </form>

                        {{--<a href="{{ route('branch.delete', [$branch->id]) }}" class="btn btn-delete">delete</a>--}}
                    </td>
                </tr>
                @endforeach

                </tbody>
            </table>


            {!! $all_branches->links() !!}

        </div>
    </div>
@stop


